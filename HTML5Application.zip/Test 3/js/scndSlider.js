/*
 * Variables
 */
 
/*
 *  Thouse Variables must me set corectly;
 */

var caruselID = "secndSlider";  // id of carusel container
var containerID = "portfolioSliderHolder"; //ID of "items to slide" container
var bubbleID = "navArrow";    // ID of bubble;
var bubbleHolderID = "arrowHolder"; // ID of Bubbble holder;
var itemID = "scndSliderItem";
var itemClassNameNoDot = "portfolioSliderItem";
var itemClassName = ".portfolioSliderItem";  // Class name of Items to slide, WARNING it must have "." before the class name
var bubbleClassName = ".arrow"; // // Class name of bubbles, WARNING it must have "." before the class name

var SinhroniseBubbles = false; // false - NO,      TRUE - YES

var itemA = document.getElementsByClassName(itemClassNameNoDot); // class name of elements to slide
var bubbleHolderElem = document.getElementById(bubbleHolderID); // ID of bubble holder element
var bubbleElem = document.getElementById(bubbleID); //ID name of bubble;
var containerElem = document.getElementById(containerID);




var SlideDuration = "1s"; // duration of one slide in secnds;
var IntervalBetweenSlides = "a"; // interval in milisecnds    WARNING: IT CANNOT BE LOWER THEN "SlideDuration"!! 
// do not change thouse values;
var caruselWidth = 0;
var slidePosition = 1;
var picNumber = 4;
var premitionToSlide = true;

/*
 * slider functions 
 */

function AddBubble() {
    var elem = bubbleElem;
    var holder = bubbleHolderElem;

    var NumberToAdd = itemA.length - 1;

    for (var i = 0; i < NumberToAdd; i++) {
        var cln = elem.cloneNode(true);
        cln.setAttribute("data-number", i + 2);
        holder.appendChild(cln);
    }
}


/*
 * This function is synchronising slider with bubbles
 */

function SliderBubbleSinh() {
    /*
     *  value if css atribute margin-left; container margin-left
     */
    if (SinhroniseBubbles) {
        var position = GetStyleValue(containerID, "margin-left");
        console.log(position);
        /*
         *  width of container and item (ther width must be equall!!)
         */
        SinhContainerItemWidth();
        var parsedPosition = parseInt(position);
        if (parsedPosition < 0) {
            parsedPosition *= -1;
        }
        var parsedCaruselWidth = parseInt(caruselWidth);
        console.log(parsedCaruselWidth);
        Math.round(picNumber);
        slidePosition = picNumber;
        var Bubbles = document.querySelectorAll(bubbleClassName);
        for (var i = 0; i < Bubbles.length; i++) {
            var BubbleDataNumber = Bubbles[i].getAttribute('data-number');
            if (BubbleDataNumber == picNumber) {
                Bubbles[i].classList.add("active");
            } else {
                Bubbles[i].classList.remove("active");
            }
        }
    }



}

/*
 * This function is synchronising carusel width with width of sliding items (it makes it responsive);
 */

function SinhContainerItemWidth() {
    /*
     * get width of container   carusel width
     */

    var width = parseFloat(GetStyleValue(caruselID, "width"))/4;
    console.log(width);
    caruselWidth = width + "px";

    /*
     * use with of container to set width of carusel item
     */

    var items = document.querySelectorAll(itemClassName);
    for (var i = 0; i < items.length; i++) {
        items[i].style.width = width + "px";
    }
    var mult = slidePosition - 1;
    if (slidePosition >= 1) {
        var margin = width * mult * (-1) + "px";
        document.getElementById(containerID).style.marginLeft = margin;
    }

}

function NextSlideTwo() {
    if (premitionToSlide) {
        premitionToSlide = false;
        picNumber += 1;
        SliderBubbleSinh();
        var elem = containerElem;
        var step = GetStyleValue(itemID, "width");
        if (picNumber <= itemA.length) {
            Slide(step, "Next");
        } else {
            Slide(0, "BackToStart")
        }
    }
}

function Slide(step, where) {

    var marginLeft = GetStyleValue(containerID, "margin-left");
    marginLeft = parseInt(marginLeft);
    if (where == "Next") {
        var parsedStep = parseInt(step) * (-1);
        var elem = containerElem;
        var newMarginLeft = marginLeft + parsedStep + "px";
        elem.style.transition = SlideDuration;
        elem.style.marginLeft = newMarginLeft;
        setTimeout(function () {
            
            elem.style.transition = "0s";
            premitionToSlide = true;
        }, 1200);
    } else if (where == "BackToStart") {
        var elem = containerElem;
        elem.style.transition = SlideDuration;
        elem.style.marginLeft = 0;
        picNumber = 4;
        slidePosition = 4;

        setTimeout(function () {
         
            elem.style.transition = "0s";
           
            premitionToSlide = true;
        }, 1200);
    }



}

function SlideToPicTwo(bubble) {
    
    var elem = containerElem;
    var width = parseFloat(GetStyleValue(caruselID, "width"));
    var BubbleNumber = bubble.getAttribute('data-number');
    picNumber = BubbleNumber;
    slidePosition = BubbleNumber;
    SliderBubbleSinh();
    var newMarginLeft = width * (BubbleNumber - 1);
    newMarginLeft = "-" + newMarginLeft + "px"
    elem.style.transition = "1s";
    elem.style.marginLeft = newMarginLeft;
    setTimeout(function () {
        elem.style.transition = "0s";
        
    }, 1200);
}


//var intervalID;
//function intervalManager(flag) {
//
//    if (flag)
//        intervalID = setInterval(NextSlide, IntervalBetweenSlides);
//    else
//        clearInterval(intervalID);
//}

function GetStyleValue(elemID, attribute) {
    var element = document.getElementById(elemID);
    var style = window.getComputedStyle(element);
    var value = style.getPropertyValue(attribute);
    return value;
}



SinhContainerItemWidth();


window.addEventListener("resize", SliderBubbleSinh);

