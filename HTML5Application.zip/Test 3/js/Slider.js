/*
             * Variables
             */
            var SlideDuration = "1s"; // duration of one slide in secnds;
            var IntervalBetweenSlides = 5000; // interval in milisecnds    WARNING: IT CANNOT BE LOWER THEN "SlideDuration"!! 
            // do not change thouse values;
            var a = document.getElementsByClassName("item"); // 
            var caruselWidth = 0;
            var slidePosition = 1;
            var picNumber = 1;

            /*
             * slider functions 
             */

            function AddBubble() {
                var elem = document.getElementById("JS-Bubble");
                var holder = document.getElementById("JS-BubbleHolder");

                var NumberToAdd = a.length - 1;

                for (var i = 0; i < NumberToAdd; i++) {
                    var cln = elem.cloneNode(true);
                    cln.setAttribute("data-number", i + 2);
                    holder.appendChild(cln);
                }
            }


            /*
             * This function is synchronising slider with bubbles
             */

            function SliderBubbleSinh() {
                /*
                 *  value if css atribute margin-left; container margin-left
                 */

                var position = GetStyleValue("container", "margin-left");

                /*
                 *  width of container and item (ther width must be equall!!)
                 */
                SinhContainerItemWidth();
                var parsedPosition = parseInt(position);
                if (parsedPosition < 0) {
                    parsedPosition *= -1;
                }
                var parsedCaruselWidth = parseInt(caruselWidth);
                Math.round(picNumber);
                slidePosition = picNumber;
                var Bubbles = document.querySelectorAll("#JS-Bubble");
                for (var i = 0; i < Bubbles.length; i++) {
                    var BubbleDataNumber = Bubbles[i].getAttribute('data-number');
                    if (BubbleDataNumber == picNumber) {
                        Bubbles[i].classList.add("active");
                    } else {
                        Bubbles[i].classList.remove("active");
                    }
                }

            }

            /*
             * This function is synchronising carusel width with width of sliding items (it makes it responsive);
             */

            function SinhContainerItemWidth() {
                /*
                 * get width of container   carusel width
                 */

                var width = parseFloat(GetStyleValue("carusel", "width"));
                caruselWidth = width + "px";

                /*
                 * use with of container to set width of carusel item
                 */

                var items = document.querySelectorAll(".item");
                for (var i = 0; i < items.length; i++) {
                    items[i].style.width = width + "px";
                }
                var mult = slidePosition - 1;
                if (slidePosition >= 1) {
                    var margin = width * mult * (-1) + "px";
                    document.getElementById("container").style.marginLeft = margin;
                }

            }

            function NextSlide() {
                picNumber += 1;
                SliderBubbleSinh();
                var elem = document.getElementById("container");
                var step = GetStyleValue("carusel", "width");
                if (picNumber <= a.length) {
                    Slide(step, "Next");
                } else {
                    Slide(0, "BackToStart")
                }
            }

            function Slide(step, where) {
                var marginLeft = GetStyleValue("container", "margin-left");
                marginLeft = parseInt(marginLeft);
                if (where == "Next") {
                    var parsedStep = parseInt(step) * (-1);
                    var elem = document.getElementById("container");
                    var newMarginLeft = marginLeft + parsedStep + "px";
                    elem.style.transition = SlideDuration;
                    elem.style.marginLeft = newMarginLeft;
                    setTimeout(function () {
                        SliderBubbleSinh();
                        elem.style.transition = "0s";
                    }, 1200);
                } else if (where == "BackToStart") {
                    var elem = document.getElementById("container");
                    elem.style.transition = SlideDuration;
                    elem.style.marginLeft = 0;
                    picNumber = 1;
                    slidePosition = 1;

                    setTimeout(function () {
                        SliderBubbleSinh();
                        elem.style.transition = "0s";
                    }, 1200);
                }

            }

            function SlideToPic(bubble) {
                intervalManager(false);
                var elem = document.getElementById("container");
                var width = parseFloat(GetStyleValue("carusel", "width"));
                var BubbleNumber = bubble.getAttribute('data-number');
                picNumber = BubbleNumber;
                slidePosition = BubbleNumber;
                SliderBubbleSinh();
                var newMarginLeft = width * (BubbleNumber - 1);
                newMarginLeft = "-" + newMarginLeft + "px"
                elem.style.transition = "1s";
                elem.style.marginLeft = newMarginLeft;
                setTimeout(function () {
                    elem.style.transition = "0s";
                }, 1200);
                intervalManager(true);
            }


//            var intervalID;
//            function intervalManager(flag) {
//
//                if (flag)
//                    intervalID = setInterval(NextSlide, IntervalBetweenSlides);
//                else
//                    clearInterval(intervalID);
//            }

            function GetStyleValue(elemID, attribute) {
                var element = document.getElementById(elemID);
                var style = window.getComputedStyle(element);
                var value = style.getPropertyValue(attribute);
                return value;
            }

            AddBubble();
            SliderBubbleSinh();
            SinhContainerItemWidth();
            intervalManager(true);

            window.addEventListener("resize", SliderBubbleSinh);
